package Model;

public class payrollmodel {
	private int id;
	private String pdate;
	private String ppdate;
	private String tdate;
	private String fullname;
	private int hrate;
	private int hwork;
	private int ahour;
	private int othour;
	private int deduction;
	private int rearnings;
	private int aearnings;
	private int otearnings;
	private int gpay;
	private int npay;
	private int tax;
	private int sss;
	private int pagibig;
	private int philhealth;
	
	
	
	
	public payrollmodel(String pdate, String ppdate, String tdate, String fullname, int hrate, int hwork, int ahour,
			int othour, int deduction, int rearnings, int aearnings, int otearnings, int gpay, int npay, int tax,
			int sss, int pagibig, int philhealth) {
		super();
		this.pdate = pdate;
		this.ppdate = ppdate;
		this.tdate = tdate;
		this.fullname = fullname;
		this.hrate = hrate;
		this.hwork = hwork;
		this.ahour = ahour;
		this.othour = othour;
		this.deduction = deduction;
		this.rearnings = rearnings;
		this.aearnings = aearnings;
		this.otearnings = otearnings;
		this.gpay = gpay;
		this.npay = npay;
		this.tax = tax;
		this.sss = sss;
		this.pagibig = pagibig;
		this.philhealth = philhealth;
	}
	
	public payrollmodel(int id, String pdate, String ppdate, String tdate, String fullname, int hrate, int hwork,
			int ahour, int othour, int deduction, int rearnings, int aearnings, int otearnings, int gpay, int npay,
			int tax, int sss, int pagibig, int philhealth) {
		super();
		this.id = id;
		this.pdate = pdate;
		this.ppdate = ppdate;
		this.tdate = tdate;
		this.fullname = fullname;
		this.hrate = hrate;
		this.hwork = hwork;
		this.ahour = ahour;
		this.othour = othour;
		this.deduction = deduction;
		this.rearnings = rearnings;
		this.aearnings = aearnings;
		this.otearnings = otearnings;
		this.gpay = gpay;
		this.npay = npay;
		this.tax = tax;
		this.sss = sss;
		this.pagibig = pagibig;
		this.philhealth = philhealth;
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPdate() {
		return pdate;
	}
	public void setPdate(String pdate) {
		this.pdate = pdate;
	}
	public String getPpdate() {
		return ppdate;
	}
	public void setPpdate(String ppdate) {
		this.ppdate = ppdate;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public int getHrate() {
		return hrate;
	}
	public void setHrate(int hrate) {
		this.hrate = hrate;
	}
	public int getHwork() {
		return hwork;
	}
	public void setHwork(int hwork) {
		this.hwork = hwork;
	}
	public int getAhour() {
		return ahour;
	}
	public void setAhour(int ahour) {
		this.ahour = ahour;
	}
	public int getOthour() {
		return othour;
	}
	public void setOthour(int othour) {
		this.othour = othour;
	}
	public int getDeduction() {
		return deduction;
	}
	public void setDeduction(int deduction) {
		this.deduction = deduction;
	}
	public int getRearnings() {
		return rearnings;
	}
	public void setRearnings(int rearnings) {
		this.rearnings = rearnings;
	}
	public int getAearnings() {
		return aearnings;
	}
	public void setAearnings(int aearnings) {
		this.aearnings = aearnings;
	}
	public int getOtearnings() {
		return otearnings;
	}
	public void setOtearnings(int otearnings) {
		this.otearnings = otearnings;
	}
	public int getGpay() {
		return gpay;
	}
	public void setGpay(int gpay) {
		this.gpay = gpay;
	}
	public int getNpay() {
		return npay;
	}
	public void setNpay(int npay) {
		this.npay = npay;
	}
	public int getTax() {
		return tax;
	}
	public void setTax(int tax) {
		this.tax = tax;
	}
	public int getSss() {
		return sss;
	}
	public void setSss(int sss) {
		this.sss = sss;
	}
	public int getPagibig() {
		return pagibig;
	}
	public void setPagibig(int pagibig) {
		this.pagibig = pagibig;
	}
	public int getPhilhealth() {
		return philhealth;
	}
	public void setPhilhealth(int philhealth) {
		this.philhealth = philhealth;
	}

	
	
	
	
}
