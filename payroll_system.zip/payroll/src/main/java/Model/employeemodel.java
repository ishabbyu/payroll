package Model;

public class employeemodel {
	private int id;
	private String lastname;
	private String firstname;
	private String middlename;
	private String jobtitle;
	private int hourlyrate;
	
	 public employeemodel() {}
	
	public employeemodel(String lastname, String firstname, String middlename, String jobtitle, int hourlyrate) {
		super();
		this.lastname = lastname;
		this.firstname = firstname;
		this.middlename = middlename;
		this.jobtitle = jobtitle;
		this.hourlyrate = hourlyrate;
	}
	public employeemodel(int id, String lastname, String firstname, String middlename, String jobtitle,
			int hourlyrate) {
		super();
		this.id = id;
		this.lastname = lastname;
		this.firstname = firstname;
		this.middlename = middlename;
		this.jobtitle = jobtitle;
		this.hourlyrate = hourlyrate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getMiddlename() {
		return middlename;
	}
	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	public int getHourlyrate() {
		return hourlyrate;
	}
	public void setHourlyrate(int hourlyrate) {
		this.hourlyrate = hourlyrate;
	}
	
	
	
}
