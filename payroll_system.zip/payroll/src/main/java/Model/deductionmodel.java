package Model;

public class deductionmodel {
	
	private int id;
	private int sss;
	private int pagibig;
	private int philhealth;
	
	
	public deductionmodel(int sss, int pagibig, int philhealth) {
		super();
		this.sss = sss;
		this.pagibig = pagibig;
		this.philhealth = philhealth;
	}
	
	public deductionmodel(int id, int sss, int pagibig, int philhealth) {
		super();
		this.id = id;
		this.sss = sss;
		this.pagibig = pagibig;
		this.philhealth = philhealth;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSss() {
		return sss;
	}
	public void setSss(int sss) {
		this.sss = sss;
	}
	public int getPagibig() {
		return pagibig;
	}
	public void setPagibig(int pagibig) {
		this.pagibig = pagibig;
	}
	public int getPhilhealth() {
		return philhealth;
	}
	public void setPhilhealth(int philhealth) {
		this.philhealth = philhealth;
	}

	

}
