package Web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dao.employeedao;
import Model.employeemodel;
import Dao.payrolldao;
import Model.payrollmodel;
import Dao.deductiondao;
import Model.deductionmodel;


@WebServlet("/")
public class employeeweb extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private employeedao employeedao;
    private payrolldao payrolldao;
    private deductiondao deductiondao;

    public void init() {
    	employeedao = new employeedao();
    	payrolldao = new payrolldao();
    	deductiondao = new deductiondao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    	    throws ServletException, IOException {
    	        doGet(request, response);
    	    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    	    throws ServletException, IOException {
    	        String action = request.getServletPath();

    	        try {
    	            switch (action) {
    	                case "/new":
    	                    showNewForm(request, response);
    	                    break;
    	                case "/new1":
    	                    showNewForm1(request, response);
    	                    break;
    	                case "/insert":
    	                    insertEmployee(request, response);
    	                    break;
    	                case "/insert1":
    	                    insertPayroll(request, response);
    	                    break;
    	                case "/Employee":
    	                    listEmployee1(request, response);
    	                    break;
    	                case "/Payroll":
    	                    listEmployee2(request, response);
    	                    break;
    	                case "/History":
    	                    listHistory(request, response);
    	                    break;
    	                case "/Deduction":
    	                    listDeduction(request, response);
    	                    break;
    	                case "/view":
    	                    showViewForm(request, response);
    	                    break;
    	                case "/print":
    	                    Printform(request, response);
    	                    break;
    	                case "/editemployee":
    	                    Editemployee(request, response);
    	                    break;
    	                case "/updateemployee":
    	                    Updateemployee(request, response);
    	                    break;
    	                case "/updated":
    	                    Updatededuction(request, response);
    	                    break;
    	                case "/editd":
    	                	Editdeduction(request, response);
    	                    break;
    	                case "/deleteemployee":
    	                    deleteEmployee(request, response);
    	                    break;
//    	                case "/delete":
//    	                    deleteEmployee(request, response);
//    	                    break;
//    	                case "/edit":
//    	                    showEditEmployee(request, response);
//    	                    break;
//    	                case "/update":
//    	                    updateEmployee(request, response);
//    	                    break;
    	                default:
    	                    listEmployee(request, response);
    	                    break;
    	            }
    	        } catch (SQLException ex) {
    	            throw new ServletException(ex);
    	        }
    	    }
	
    private void listEmployee(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException, ServletException {
    	        List < employeemodel > listEmployee = employeedao.selectAllEmployee();
    	        request.setAttribute("listEmployee", listEmployee);
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("employee.jsp");
    	        dispatcher.forward(request, response);
    	    }
    
    private void listEmployee1(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException, ServletException {
    	        List < employeemodel > listEmployee = employeedao.selectAllEmployee();
    	        request.setAttribute("listEmployee", listEmployee);
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("employee.jsp");
    	        dispatcher.forward(request, response);
    	    }
    
    private void listEmployee2(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException, ServletException {
    	        List < employeemodel > listEmployee = employeedao.selectAllEmployee();
    	        request.setAttribute("listEmployee", listEmployee);
    	        List < deductionmodel > listDeduction = deductiondao.selectAllDeduction();
    	        request.setAttribute("listDeduction", listDeduction);
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("processpayroll.jsp");
    	        dispatcher.forward(request, response);
    	    }
    
    private void listDeduction(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException, ServletException {
    	        List < deductionmodel > listDeduction = deductiondao.selectAllDeduction();
    	        request.setAttribute("listDeduction", listDeduction);
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("setting.jsp");
    	        dispatcher.forward(request, response);
    	    }
    
    private void listHistory(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException, ServletException {
    	        List < payrollmodel > listHistory = payrolldao.selectAllPayroll();
    	        request.setAttribute("listHistory", listHistory);
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("payrollhistory.jsp");
    	        dispatcher.forward(request, response);
    	    }

    

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
    	    throws ServletException, IOException {
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("employee.jsp");
    	        dispatcher.forward(request, response);
    	    }
    
    private void showNewForm1(HttpServletRequest request, HttpServletResponse response)
    	    throws ServletException, IOException {
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("processpayroll.jsp");
    	        dispatcher.forward(request, response);
    	    }

    
    private void insertEmployee(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException {
    	        String lastname = request.getParameter("lastname");
    	        String firstname = request.getParameter("firstname");
    	        String middlename = request.getParameter("middlename");
    	        String jobtitle = request.getParameter("jobtitle");
    	        int hourlyrate = Integer.parseInt(request.getParameter("hourlyrate"));    	        
    	    
    	        employeemodel newEmployee = new employeemodel(lastname, firstname, middlename, jobtitle, hourlyrate);
    	        employeedao.insertEmployee(newEmployee);
    	        response.sendRedirect("list");
    	    }
    
    private void insertPayroll(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException, ServletException {
	    	 String pdate = request.getParameter("pdate");
	         String ppdate = request.getParameter("ppdate");
	         String tdate = request.getParameter("tdate");
	         String fullname = request.getParameter("fullname");
	         int hrate = Integer.parseInt(request.getParameter("hrate"));
	         int hwork = Integer.parseInt(request.getParameter("hwork"));
	         int ahour = Integer.parseInt(request.getParameter("ahour"));
	         int othour = Integer.parseInt(request.getParameter("othour"));
	         int deduction = Integer.parseInt(request.getParameter("deduction"));
	         int rearnings = Integer.parseInt(request.getParameter("rearnings"));
	         int aearnings = Integer.parseInt(request.getParameter("aearnings"));
	         int otearnings = Integer.parseInt(request.getParameter("otearnings"));
	         int gpay = Integer.parseInt(request.getParameter("gpay"));
	         int npay = Integer.parseInt(request.getParameter("npay"));
	         int tax = Integer.parseInt(request.getParameter("tax"));
	         int sss = Integer.parseInt(request.getParameter("sss"));
	         int pagibig = Integer.parseInt(request.getParameter("pagibig"));
	         int philhealth = Integer.parseInt(request.getParameter("philhealth"));

	         
	         rearnings = hrate * hwork;
	         aearnings = ahour * hrate;
	         otearnings = othour * hrate;
	         gpay = rearnings + aearnings + otearnings;
	         
	         if(gpay >= 20000) {
	        	 tax = gpay * 10/100;
	        	 npay = gpay - (tax + sss + pagibig + philhealth + deduction);
	         }
	         else if(gpay >= 30000) {
	        	 tax = gpay * 15/100;
	        	 npay = gpay - (tax + sss + pagibig + philhealth + deduction);
	         }
	         else {
	        	 tax = gpay * 5/100;
	        	 npay = gpay - (tax + sss + pagibig + philhealth + deduction);
	         }
	         
	        
	         	
         	payrollmodel newPayroll = new payrollmodel(pdate, ppdate, tdate, fullname, hrate, hwork, ahour, othour, deduction, rearnings, aearnings, otearnings, gpay, npay, tax, sss, pagibig, philhealth);
	        payrolldao.insertPayroll(newPayroll);
	        RequestDispatcher dispatcher = request.getRequestDispatcher("processpayroll.jsp");
	        dispatcher.forward(request, response);
    	       
    	    }
    
    		private void showViewForm(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, ServletException, IOException {
    	        int id = Integer.parseInt(request.getParameter("id"));
    	        payrollmodel existingPayroll = payrolldao.selectPayroll(id);
    	        RequestDispatcher dispatcher = request.getRequestDispatcher("payrollreview.jsp");
    	        request.setAttribute("payroll", existingPayroll);
    	        dispatcher.forward(request, response);

    	    }
    		
    		private void Printform(HttpServletRequest request, HttpServletResponse response)
    	    	    throws SQLException, ServletException, IOException {
    	    	        int id = Integer.parseInt(request.getParameter("id"));
    	    	        payrollmodel existingPayroll = payrolldao.selectPayroll(id);
    	    	        RequestDispatcher dispatcher = request.getRequestDispatcher("printform.jsp");
    	    	        request.setAttribute("payroll", existingPayroll);
    	    	        dispatcher.forward(request, response);

    	    	    }
    		
    		private void Editemployee(HttpServletRequest request, HttpServletResponse response)
    	    	    throws SQLException, ServletException, IOException {
    	    	        int id = Integer.parseInt(request.getParameter("id"));
    	    	        employeemodel existingEmployee = employeedao.selectEmployee(id);
    	    	        RequestDispatcher dispatcher = request.getRequestDispatcher("employee.jsp");
    	    	        request.setAttribute("employee", existingEmployee);
    	    	        dispatcher.forward(request, response);

    	    	    }
    		
		 private void Updateemployee(HttpServletRequest request, HttpServletResponse response)
			    throws SQLException, IOException {
			        int id = Integer.parseInt(request.getParameter("id"));
			        String lastname =request.getParameter("lastname");
			        String firstname = request.getParameter("firstname");
			        String middlename =request.getParameter("middlename");
			        String jobtitle =request.getParameter("jobtitle");
			        int hourlyrate = Integer.parseInt(request.getParameter("hourlyrate"));

			        employeemodel employee = new employeemodel(id, lastname, firstname,middlename,jobtitle, hourlyrate);
			        employeedao.updateEmployee(employee);
			        response.sendRedirect("list");
			    }
    		
    		private void Editdeduction(HttpServletRequest request, HttpServletResponse response)
    	    	    throws SQLException, ServletException, IOException {
    	    	        int id = Integer.parseInt(request.getParameter("id"));
    	    	        deductionmodel existingDeduction = deductiondao.selectDeduction(id);
    	    	        RequestDispatcher dispatcher = request.getRequestDispatcher("setting.jsp");
    	    	        request.setAttribute("deduction", existingDeduction);
    	    	        dispatcher.forward(request, response);

    	    	    }
    		
    		 private void Updatededuction(HttpServletRequest request, HttpServletResponse response)
    				    throws SQLException, IOException {
    				        int id = Integer.parseInt(request.getParameter("id"));
    				        int sss = Integer.parseInt(request.getParameter("sss"));
    				        int pagibig = Integer.parseInt(request.getParameter("pagibig"));
    				        int philhealth = Integer.parseInt(request.getParameter("philhealth"));

    				        deductionmodel deduction = new deductionmodel(id, sss, pagibig, philhealth);
    				        deductiondao.updateDeduction(deduction);
    				        response.sendRedirect("index.jsp");
    				    }
    		 
    		 private void deleteEmployee(HttpServletRequest request, HttpServletResponse response)
    				    throws SQLException, IOException {
    				        int id = Integer.parseInt(request.getParameter("id"));
    				        employeedao.deleteEmployee(id);
    				        response.sendRedirect("list");

    				    }
}
