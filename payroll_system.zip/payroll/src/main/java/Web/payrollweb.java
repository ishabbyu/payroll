//package Web;
//
//import java.io.IOException;
//
//import javax.servlet.RequestDispatcher;
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import Dao.payrolldao;
//import Model.payrollmodel;
//
//@WebServlet("/payroll")
//public class payrollweb extends HttpServlet{
//	
//	 private static final long serialVersionUID = 1L;
//	 private payrolldao payrolldao;
//	 
//	 public void init() {
//		 payrolldao = new payrolldao();
//		 
//	 }
//	 
//	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
//			    throws ServletException, IOException {
//			        input(request, response);
//			    }
//
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//    throws ServletException, IOException {
//        response.sendRedirect("processpayroll.jsp");
//			    }
//    
//    private void input(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
//        String pdate = request.getParameter("pdate");
//        String ppdate = request.getParameter("ppdate");
//        String tdate = request.getParameter("tdate");
//        String fullname = request.getParameter("fullname");
//        int hrate = Integer.parseInt(request.getParameter("hrate"));
//        int hwork = Integer.parseInt(request.getParameter("hwork"));
//        int ahour = Integer.parseInt(request.getParameter("ahour"));
//        int othour = Integer.parseInt(request.getParameter("othour"));
//        int aearnings = Integer.parseInt(request.getParameter("aearnings"));
//        int deduction = Integer.parseInt(request.getParameter("deduction"));
//
//        payrollmodel payroll = new payrollmodel();
//        payroll.setPdate(pdate);
//        payroll.setPpdate(ppdate);
//        payroll.setTdate(tdate);
//        payroll.setFullname(fullname);
//        payroll.setHrate(hrate);
//        payroll.setHwork(hwork);
//        payroll.setAhour(ahour);
//        payroll.setOthour(othour);
//        payroll.setAearnings(aearnings);
//        payroll.setDeduction(deduction);
//        
//        try {
//            int result = payrolldao.insertPayroll(payroll);
//            if (result == 1) {
//                request.setAttribute("NOTIFICATION", "User Registered Successfully!");
//            }
//
//        } catch (Exception e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//
//
//        RequestDispatcher dispatcher = request.getRequestDispatcher("processpayroll.jsp");
//        dispatcher.forward(request, response);
//    }
//}
