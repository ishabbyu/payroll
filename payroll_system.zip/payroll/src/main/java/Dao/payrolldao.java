package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Model.payrollmodel;

public class payrolldao {

	private String jdbcURL = "jdbc:mysql://localhost:3306/payroll?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "camacho123";
    
    private static final String INSERT_PAYMENT_SQL = "INSERT INTO payment" + "  (pdate, ppdate, tdate, fullname, hrate, hwork, ahour, othour, deduction, rearnings, aearnings, otearnings, gpay, npay, tax, sss, pagibig, philhealth) VALUES " +
	        " (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

    private static final String SELECT_PAYMENT_BY_ID = "select id,pdate,ppdate,tdate,fullname,hrate,hwork,ahour,othour,deduction,rearnings,aearnings,otearnings,gpay,npay,tax,sss,pagibig,philhealth from payment where id =?";
    private static final String SELECT_ALL_PAYMENT = "select * from payment";
	
    
    public payrolldao() {}
    
    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return connection;
    }
    
    int result = 0;
    public int insertPayroll(payrollmodel payroll) throws SQLException {
        System.out.println(INSERT_PAYMENT_SQL);
        // try-with-resource statement will auto close the connection.
        try (Connection connection = getConnection(); PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PAYMENT_SQL)) {
            preparedStatement.setString(1, payroll.getPdate());
            preparedStatement.setString(2, payroll.getPpdate());
            preparedStatement.setString(3, payroll.getTdate());
            preparedStatement.setString(4, payroll.getFullname());
            preparedStatement.setInt(5, payroll.getHrate());
            preparedStatement.setInt(6, payroll.getHwork());
            preparedStatement.setInt(7, payroll.getAhour());
            preparedStatement.setInt(8, payroll.getOthour());
            preparedStatement.setInt(9, payroll.getDeduction());
            preparedStatement.setInt(10, payroll.getRearnings());
            preparedStatement.setInt(11, payroll.getAearnings());
            preparedStatement.setInt(12, payroll.getOtearnings());
            preparedStatement.setInt(13, payroll.getGpay());
            preparedStatement.setInt(14, payroll.getNpay());
            preparedStatement.setInt(15, payroll.getTax());
            preparedStatement.setInt(16, payroll.getSss());
            preparedStatement.setInt(17, payroll.getPagibig());
            preparedStatement.setInt(18, payroll.getPhilhealth());
//            preparedStatement.setInt(18, payroll.getTotald());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            printSQLException(e);
        }
        return result;
    }
    
    public payrollmodel selectPayroll(int id) {
    	payrollmodel payroll = null;
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_PAYMENT_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
            	String pdate = rs.getString("pdate");
                String ppdate = rs.getString("ppdate");
                String tdate = rs.getString("tdate");
                String fullname = rs.getString("fullname");
                int hrate = rs.getInt("hrate");
                int hwork = rs.getInt("hwork");
                int ahour = rs.getInt("ahour");
                int othour = rs.getInt("othour");
                int deduction = rs.getInt("deduction");
                int rearnings = rs.getInt("rearnings");
                int aearnings = rs.getInt("aearnings");
                int otearnings = rs.getInt("otearnings");
                int gpay = rs.getInt("gpay");
                int npay = rs.getInt("npay");
                int tax = rs.getInt("tax");
                int sss = rs.getInt("sss");
                int pagibig = rs.getInt("pagibig");
                int philhealth = rs.getInt("philhealth");
//                int totald = rs.getInt("totald");
                payroll = new payrollmodel(id, pdate, ppdate, tdate, fullname, hrate, hwork, ahour, othour, deduction, rearnings, aearnings, otearnings, gpay, npay, tax, sss, pagibig, philhealth);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return payroll;
    }
    
    public List < payrollmodel > selectAllPayroll() {

        // using try-with-resources to avoid closing resources (boiler plate code)
        List < payrollmodel > payroll = new ArrayList < > ();
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_PAYMENT);) {
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int id = rs.getInt("id");
                String pdate = rs.getString("pdate");
                String ppdate = rs.getString("ppdate");
                String tdate = rs.getString("tdate");
                String fullname = rs.getString("fullname");
                int hrate = rs.getInt("hrate");
                int hwork = rs.getInt("hwork");
                int ahour = rs.getInt("ahour");
                int othour = rs.getInt("othour");
                int deduction = rs.getInt("deduction");
                int rearnings = rs.getInt("rearnings");
                int aearnings = rs.getInt("aearnings");
                int otearnings = rs.getInt("otearnings");
                int gpay = rs.getInt("gpay");
                int npay = rs.getInt("npay");
                int tax = rs.getInt("tax");
                int sss = rs.getInt("sss");
                int pagibig = rs.getInt("pagibig");
                int philhealth = rs.getInt("philhealth");
//                int totald = rs.getInt("totald");
                payroll.add(new payrollmodel(id, pdate, ppdate, tdate, fullname, hrate, hwork, ahour, othour, deduction, rearnings, aearnings, otearnings, gpay, npay, tax, sss, pagibig, philhealth));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return payroll;
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
    
}
