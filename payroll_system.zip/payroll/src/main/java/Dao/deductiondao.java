package Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Model.deductionmodel;

public class deductiondao {
	
	private String jdbcURL = "jdbc:mysql://localhost:3306/payroll?useSSL=false";
    private String jdbcUsername = "root";
    private String jdbcPassword = "camacho123";
    
    
    private static final String SELECT_DEDUCTION_BY_ID = "select id,sss,pagibig,philhealth from deduction where id =?";
    private static final String SELECT_ALL_DEDUCTION = "select * from deduction";
    private static final String UPDATE_DEDUCTION_SQL = "update deduction set sss = ?,pagibig= ?, philhealth = ? where id = ?;";


    public deductiondao() {}
    
    protected Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return connection;
    }
    
    
    public deductionmodel selectDeduction(int id) {
    	deductionmodel deduction = null;
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_DEDUCTION_BY_ID);) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int sss = rs.getInt("sss");
                int pagibig = rs.getInt("pagibig");
                int philhealth = rs.getInt("philhealth");
                deduction = new deductionmodel(id, sss, pagibig, philhealth);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return deduction;
    }
    
    public List < deductionmodel > selectAllDeduction() {

        // using try-with-resources to avoid closing resources (boiler plate code)
        List < deductionmodel > deduction = new ArrayList < > ();
        // Step 1: Establishing a Connection
        try (Connection connection = getConnection();

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_DEDUCTION);) {
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            ResultSet rs = preparedStatement.executeQuery();

            // Step 4: Process the ResultSet object.
            while (rs.next()) {
                int id = rs.getInt("id");
                int sss = rs.getInt("sss");
                int pagibig = rs.getInt("pagibig");
                int philhealth = rs.getInt("philhealth");
                deduction.add(new deductionmodel(id,sss, pagibig, philhealth));
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return deduction;
    }
    
    
    public boolean updateDeduction(deductionmodel deduction) throws SQLException {
        boolean rowUpdated;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(UPDATE_DEDUCTION_SQL);) {
            statement.setInt(1, deduction.getSss());
            statement.setInt(2, deduction.getPagibig());
            statement.setInt(3, deduction.getPhilhealth());
            statement.setInt(4, deduction.getId());

            rowUpdated = statement.executeUpdate() > 0;
        }
        return rowUpdated;
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }

}
